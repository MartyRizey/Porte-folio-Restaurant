<?php

// Config fuseau horaire utilisé
date_default_timezone_set('Europe/Paris');

// Config de la connexion BDD
$config = [
  'host'     => 'localhost',
  'dbname'   => 'Porte-folio',
  'user'     => 'philippe48',
  'password' => ''
  ];