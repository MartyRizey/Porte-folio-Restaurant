/*$(document).ready(function() {
   
   (function() {
      var dialog = document.getElementById('window');
      document.getElementById('oAffiche').onclick = function() {
        dialog.show();
      };
      document.getElementById('oFermer').onclick = function() {
        dialog.close();
      };
    })();
   
 
});  */


	
	
	
	
	
	
	
	
	
	
	
	
	
